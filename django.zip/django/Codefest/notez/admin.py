from django.contrib import admin

from .models import Notes

admin.site.register(Notes)
